import { IRoute } from "@core/interfaces";
import { Router } from "express";
import { AuthMiddleware, errorMiddleware } from "@core/middleware";
import Controller from "./controller";
import { CreateProjectDto } from "./dtos/create.dto";
import { UpdateProjectDto } from "./dtos/update.dto";
import { PERMISSION_TYPE } from "@core/config/constants";

export default class Route implements IRoute {
    public path = '/projects';
    public router = Router();

    public controller = new Controller();

    constructor() {
        this.initializeRoutes();
    }

    private initializeRoutes() {

        this.router.post(this.path + '/', errorMiddleware(CreateProjectDto, 'body'), AuthMiddleware.authorization(), this.controller.create);
        this.router.get(this.path + '/:id', AuthMiddleware.authorization(), this.controller.getById);
        this.router.patch(this.path + '/:id', AuthMiddleware.authorization(), AuthMiddleware.checkRole(PERMISSION_TYPE.UPDATE_PROJECT_INFO), errorMiddleware(UpdateProjectDto, 'body'), this.controller.update);
        // this.router.delete(this.path + '/:id', AuthMiddleware.authorization(), AuthMiddleware.checkRole("PROJECT", "UPDATE"), this.controller.delete);
        this.router.get(this.path + '/', AuthMiddleware.authorization(), this.controller.search);

    }
}
